# Pedido Irrecusável

<p align="center">
  <img height=200 src="https://cdn-icons-png.flaticon.com/512/6729/6729451.png">
</p>
<h1 align="center">
  Pedido Irrecusável
</h1>
<div align="center">

  <h3>Ferramentas</h3>
  <img src="https://img.shields.io/badge/PostgreSQL-316192?style=for-the-badge&logo=postgresql&logoColor=white" height="30px"/>  
  <img src="https://img.shields.io/badge/Node.js-43853D?style=for-the-badge&logo=node.js&logoColor=white" height="30px"/>  
  <img src="https://img.shields.io/badge/Express.js-404D59?style=for-the-badge&logo=express.js&logoColor=white" height="30px"/>
  
</div>

<br/>

# Descrição

Um sistema simples de convite para sair utilizando HTML, CSS e JavaScript, onde o botão de "Não" tem o comportamento de fugir do cursor e o botão de "Sim" direciona o usuário para outro link.

</br>

## Deploy

pedido-irrecusavel-seven.vercel.app

## Autora

Letícia Gomez Pinheiro 
<p>Linkedin: https://www.linkedin.com/in/leticia-pinheiro-dev/</p>
<p>GitHub: https://github.com/Leticia-Pinheiro</p>
<br/>

#
